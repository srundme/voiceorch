
        // --- 1. CINEMATIC AUDIO SYNTHESIZER (No external files needed) ---
        function playCinematicBootSound() {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            const ctx = new AudioContext();
            
            // Deep Bass Drone
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(30, ctx.currentTime); // Deep sub
            osc.frequency.exponentialRampToValueAtTime(10, ctx.currentTime + 3);
            
            gain.gain.setValueAtTime(0, ctx.currentTime);
            gain.gain.linearRampToValueAtTime(1, ctx.currentTime + 0.5);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 4);
            
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start();
            osc.stop(ctx.currentTime + 4);

            // High pitch digital 'ping'
            const ping = ctx.createOscillator();
            const pingGain = ctx.createGain();
            ping.type = 'triangle';
            ping.frequency.setValueAtTime(800, ctx.currentTime + 1);
            pingGain.gain.setValueAtTime(0, ctx.currentTime + 1);
            pingGain.gain.linearRampToValueAtTime(0.2, ctx.currentTime + 1.1);
            pingGain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 2);
            
            ping.connect(pingGain);
            pingGain.connect(ctx.destination);
            ping.start(ctx.currentTime + 1);
            ping.stop(ctx.currentTime + 2);
        }

        // --- 2. BOOT SEQUENCE LOGIC ---
        const initBtn = document.getElementById('init-btn');
        const bootScreen = document.getElementById('boot-screen');
        const bootLogo = document.getElementById('boot-logo');
        const uiLayer = document.querySelector('.ui-layer');

        initBtn.addEventListener('click', () => {
            initBtn.style.display = 'none';
            bootLogo.style.display = 'block';
            
            playCinematicBootSound();

            // Netflix-style Zoom and Reveal via GSAP
            const tl = gsap.timeline();
            
            tl.to(bootLogo, { opacity: 1, scale: 1.1, duration: 1.5, ease: "power2.out" })
              .to(bootLogo, { opacity: 0, scale: 3, duration: 0.8, ease: "power4.in" }, "+=0.5")
              .to(bootScreen, { opacity: 0, duration: 0.5, onComplete: () => {
                  bootScreen.style.display = 'none';
                  document.body.style.overflowY = 'auto'; // Unlock scroll
                  
                  // Reveal Main UI
                  gsap.to(uiLayer, { opacity: 1, duration: 1 });
                  
                  // Trigger Hero Animations
                  gsap.fromTo(".gs-up", 
                      { y: 50, opacity: 0 }, 
                      { y: 0, opacity: 1, duration: 1, stagger: 0.15, ease: "power3.out" }
                  );
              }});
        });

        // --- 3. 3D WARP SPEED PARTICLE ENGINE (Grayscale) ---
        const canvas = document.getElementById('engine-canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;

        let stars = [];
        const numStars = 800;

        for (let i = 0; i < numStars; i++) {
            stars.push({
                x: Math.random() * canvas.width - canvas.width / 2,
                y: Math.random() * canvas.height - canvas.height / 2,
                z: Math.random() * canvas.width
            });
        }

        function drawStars() {
            ctx.fillStyle = 'rgba(0, 0, 0, 0.2)'; // Motion blur effect
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            const cx = canvas.width / 2;
            const cy = canvas.height / 2;

            for (let i = 0; i < numStars; i++) {
                let star = stars[i];
                star.z -= 2; // Speed of movement towards camera

                if (star.z <= 0) {
                    star.x = Math.random() * canvas.width - canvas.width / 2;
                    star.y = Math.random() * canvas.height - canvas.height / 2;
                    star.z = canvas.width;
                }

                const px = cx + (star.x / star.z) * canvas.width;
                const py = cy + (star.y / star.z) * canvas.width;
                const size = (1 - star.z / canvas.width) * 2;

                ctx.fillStyle = `rgba(255, 255, 255, ${1 - star.z/canvas.width})`;
                ctx.beginPath();
                ctx.arc(px, py, size, 0, Math.PI * 2);
                ctx.fill();
            }
            requestAnimationFrame(drawStars);
        }
        drawStars();

        window.addEventListener('resize', () => {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        });

        // --- 4. 3D HOLOGRAPHIC TILT CARDS & MOUSE GLOW ---
        const cards = document.querySelectorAll('.tilt-card');
        
        cards.forEach(card => {
            card.addEventListener('mousemove', (e) => {
                const rect = card.getBoundingClientRect();
                const x = e.clientX - rect.left;
                const y = e.clientY - rect.top;
                
                // Update CSS variables for the radial glow
                card.style.setProperty('--mouse-x', `${x}px`);
                card.style.setProperty('--mouse-y', `${y}px`);

                // 3D Tilt Math
                const centerX = rect.width / 2;
                const centerY = rect.height / 2;
                const rotateX = ((y - centerY) / centerY) * -10; // Max 10 deg tilt
                const rotateY = ((x - centerX) / centerX) * 10;

                card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(1.02, 1.02, 1.02)`;
            });

            card.addEventListener('mouseleave', () => {
                card.style.transform = `perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1, 1, 1)`;
            });
        });

        // --- 5. SCROLL TRIGGER ANIMATIONS ---
        gsap.registerPlugin(ScrollTrigger);

        gsap.utils.toArray('.card-wrapper').forEach((wrapper, i) => {
            gsap.fromTo(wrapper, 
                { y: 100, opacity: 0 },
                {
                    y: 0,
                    opacity: 1,
                    duration: 1,
                    ease: "power3.out",
                    scrollTrigger: {
                        trigger: wrapper,
                        start: "top 85%",
                    }
                }
            );
        });